import * as React from 'react';
import { Text, View, StyleSheet } from 'react-native';
import * as Font from 'expo-font';
import AppLoading from 'expo-app-loading';

let customFonts = {
  Patrick: require('../assets/PatrickHand-Regular.ttf'),
};
export default class AppHeader extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      fontsLoaded: false,
    };
  }

  async _loadFontsAsync() {
    await Font.loadAsync(customFonts);
    this.setState({ fontsLoaded: true });
  }

  componentDidMount() {
    this._loadFontsAsync();
  }

  render() {
    if (!this.state.fontsLoaded) {
      return <AppLoading />;
    } else {
      return (
        <View style={mystyle.textContainer}>
          <Text style={mystyle.text}>Crime Spotter</Text>
        </View>
      );
    }
  }
}

const mystyle = StyleSheet.create({
  textContainer: {
    backgroundColor: '#B90E0A',
  },
  text: {
    color: 'white',
    fontSize: '30px',
    fontWeight: 'bold',
    textAlign: 'center',
    fontFamily: 'Patrick',
  },
});
