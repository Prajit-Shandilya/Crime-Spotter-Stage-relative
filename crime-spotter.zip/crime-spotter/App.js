import * as React from 'react';

import { NavigationContainer } from '@react-navigation/native';
import DrawerNavigator from './components/AppDrawerNavigator';
import { createStackNavigator } from '@react-navigation/stack';
import * as firebase from 'firebase';

import { firebaseConfig } from './config';
if (!firebase.apps.length) {
  firebase.initializeApp(firebaseConfig);
} else {
  firebase.app();
}
// You can import from local files


import LoginScreen from './screens/Loginscreen';
import { AppDrawerNavigator } from './components/AppDrawerNavigator';
import Loadingscreen from './screens/Loadingscreen';


const Stack = createStackNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Stack.Navigator
        initialRouteName="Loginscreen"
        screenOptions={{
          headerShown: false,
        }}>
        <Stack.Screen name="Loading" component={Loadingscreen} />
        <Stack.Screen name="Loginscreen" component={LoginScreen} />

        <Stack.Screen name="Main" component={DrawerNavigator} />
      </Stack.Navigator>
    </NavigationContainer>
  );
}
