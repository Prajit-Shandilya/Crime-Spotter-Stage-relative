export const firebaseConfig = {
  apiKey: 'AIzaSyCS23qZvfNwhQIYK5ljJl5IJF79fOGaL68',

  authDomain: 'crimespoter.firebaseapp.com',

  databaseURL: 'https://crimespoter-default-rtdb.firebaseio.com',

  projectId: 'crimespoter',

  storageBucket: 'crimespoter.appspot.com',

  messagingSenderId: '472406024184',

  appId: '1:472406024184:web:a431b7465b399ef862c00d',
};
// Initialize Firebase
