import * as React from 'react';
import { Text, View, StyleSheet, Image, TouchableOpacity } from 'react-native';

export default class Profile extends React.Component{
  render(){
    return(
  <View>
  <Text>This is Profile</Text>
  </View>
    )
}
}